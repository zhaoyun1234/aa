package com.wode.myexample;

import com.wode.myexample.dao.MyDao;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.support.v4.app.Fragment;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.TextView;

public class MenuFragment extends Fragment {

	private Button mButton;
	private TextView mTextView;
	private Handler mHandler = new Handler() {

		@Override
		public void handleMessage(Message msg) {
			// TODO Auto-generated method stub
			super.handleMessage(msg);
			switch (msg.what) {
			case 1:
				mTextView.setText("已登入");
				mButton.setText("退出登入");
				
				mButton.setOnClickListener(new OnClickListener() {
					@Override
					public void onClick(View v) {
						// TODO Auto-generated method stub
						new MyDao().Exitlogin(getActivity());
						String l = new MyDao().LoginStateDao(getActivity());
						Log.e("Exitlogin", l);
					}
				});
				
				break;

			case 0:
				mTextView.setText("未登入");
				mButton.setText("登入");
				mButton.setOnClickListener(new OnClickListener() {
					@Override
					public void onClick(View v) {
						// TODO Auto-generated method stub
						Intent intent = new Intent(getActivity(),
								ActivityLogin.class);
						getActivity().startActivity(intent);
						getActivity().overridePendingTransition(R.anim.go_in,
								R.anim.go_out);
					}
				});
				break;
			}
		}
	};

	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container,
			Bundle savedInstanceState) {
		return inflater.inflate(R.layout.layout_menu, null);
	}

	@Override
	public void onActivityCreated(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onActivityCreated(savedInstanceState);
		mTextView= (TextView) getActivity().findViewById(R.id.layout_menu_state);
		// 登入按钮
		mButton = (Button) getActivity().findViewById(
				R.id.layout_menu_state_btn);
		
		new Thread(new Runnable() {
			
			@Override
			public void run() {
				// TODO Auto-generated method stub
				
				String loginstate = new MyDao().LoginStateDao(getActivity());
				Log.e("loginstate", "" + loginstate);
				int a=0;
				if (loginstate.equals("1")) {
					a=1;
				} else {
					a=0;
				}
				Message msg = mHandler.obtainMessage(a,loginstate);
				mHandler.sendMessage(msg);
				
			}
		}).start();
		
	}
}
