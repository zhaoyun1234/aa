package com.wode.myexample;


import java.util.ArrayList;
import java.util.List;

import com.baidu.android.pushservice.PushConstants;
import com.baidu.android.pushservice.PushManager;
import com.google.gson.Gson;
import com.wode.myexample.adapter.ContentAdapter;
import com.wode.myexample.api.Urls;
import com.wode.myexample.dao.MyDao;
import com.wode.myexample.entity.kuaidi100.KuaiDi100;
import com.wode.myexample.util.Companytype;
import com.wode.myexample.util.NetworkUtil;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.support.v4.app.Fragment;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.AutoCompleteTextView;
import android.widget.Button;
import android.widget.ListView;
import android.widget.Toast;
import android.widget.AdapterView.OnItemClickListener;

@SuppressLint("ValidFragment")
public class ContentFragment extends Fragment {
	private Button btn;
	private AutoCompleteTextView mAutoCompleteTextView;
	private Companytype mCompanytype;
//	private ExNet mExNet ;
	private Context mContext;
	public String url;
	private ListView layout_content_listView;
	protected List<KuaiDi100> List100=new ArrayList<KuaiDi100>();
	private final String TAG = this.getClass().getSimpleName();
	private String kuaidu100 = "http://www.kuaidi100.com/query?type=";
	private String postid = "&postid=";
	private ContentAdapter adapter;
	String jsonStr ;
	private final int DATA_SUCCESS =1;
	private final int HTTP_ERROR = 2;
	private final int NET_ERROR =3;
	private List c;
	private Handler mHandler;
	
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
            Bundle savedInstanceState) {
    	
    	
        return inflater.inflate(R.layout.layout_content, null);
    }


	@Override
	public void onActivityCreated(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onActivityCreated(savedInstanceState);
  
		layout_content_listView = (ListView)getView().findViewById(R.id.layout_content_listView);
		btn = (Button) getActivity().findViewById(R.id.layout_content_btn);
		mAutoCompleteTextView=(AutoCompleteTextView) getActivity().findViewById(R.id.layout_content_autoEditText);
		mContext= getActivity().getApplicationContext();
		
		
		
		
		
		
		mHandler =new Handler(){
			
			@Override
			public void handleMessage(Message msg) {
				// TODO Auto-generated method stub
				super.handleMessage(msg);
				switch (msg.what) {
				case DATA_SUCCESS:
					List<KuaiDi100> cate =(List<KuaiDi100>) msg.obj;
					if (cate.size()==0) {
						Toast.makeText(mContext,"单号错误", Toast.LENGTH_SHORT).show();
					} else {
						Log.e("Handler", cate.toString());
						adapter =new ContentAdapter(cate, mContext);
						layout_content_listView.setAdapter(adapter);
						break;
					}
				case HTTP_ERROR:
					Toast.makeText(mContext,"单号错误", Toast.LENGTH_SHORT).show();
					break;
				case NET_ERROR:
					Toast.makeText(mContext,"网络无连接", Toast.LENGTH_SHORT).show();
					break;
				}
			}
			
			
			
		};
		
		
		
		btn.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				Log.e("text",mAutoCompleteTextView.getText().toString());
				mCompanytype= new Companytype();
				c = mCompanytype.zhengzhe(mAutoCompleteTextView.getText().toString());
				new Thread(new Runnable() {
					@Override
					public void run() {
						// TODO Auto-generated method stub
						
						try {
							
						url="";
						for (int i = 0; i < c.size(); i++) {

							if (NetworkUtil.isNetAvailable(mContext)) {
								jsonStr = NetworkUtil.getJsonStrFormUrl(kuaidu100
										+ c.get(i) + postid + mAutoCompleteTextView.getText().toString());
							} else {
								mHandler.sendEmptyMessage(NET_ERROR);
								return;
							}
							Log.e("jsonStr", jsonStr);
							KuaiDi100 mDi100=json(jsonStr);
							if (mDi100.getStatus().equals("200")) {
								Log.e(mDi100.getCom()+"公司", "状态"+mDi100.getStatus());
								List100.add(mDi100);
							} else {
							}
								if (i==c.size()-1) {
									Log.e("all json", List100.toString()); 
									Message msg =mHandler.obtainMessage(DATA_SUCCESS,List100);
									mHandler.sendMessage(msg);
								} else {
								}
						}
						} catch (NullPointerException e) {
							// TODO: handle exception
							mHandler.sendEmptyMessage(NET_ERROR);
						}
					}
				}).start();
				
			}
		});
		
		layout_content_listView.setOnItemClickListener(new OnItemClickListener() {

			@Override
			public void onItemClick(AdapterView<?> parent, View view,
					int position, long id) {
				// TODO Auto-generated method stub
				Intent intent= new Intent(getActivity(),ActivityForm.class);
				intent.putExtra("kuaidi", List100.get(position));
				getActivity().startActivity(intent);
			}
		});
	}
	

		
		
	public KuaiDi100 json(String jsonStr){
		Gson gson = new Gson();
		return gson.fromJson(jsonStr, KuaiDi100.class);
	}
   
    
}
