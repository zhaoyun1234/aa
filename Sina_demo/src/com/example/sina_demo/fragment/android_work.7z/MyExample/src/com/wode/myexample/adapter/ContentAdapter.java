package com.wode.myexample.adapter;

import java.util.ArrayList;
import java.util.List;

import com.wode.myexample.R;
import com.wode.myexample.entity.exlist.ExList;
import com.wode.myexample.entity.kuaidi100.KuaiDi100;
import com.wode.myexample.util.ExState;
import com.wode.myexample.util.ExString;

import android.content.Context;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ListView;
import android.widget.TextView;

public class ContentAdapter extends BaseAdapter{

	private List<KuaiDi100> mDi100s = new ArrayList<KuaiDi100>();
	private Context mContext;
	private LayoutInflater mLayoutInflater;
	
	public ContentAdapter(List<KuaiDi100> cate,Context mContext) {
		super();
		this.mDi100s=cate;
		this.mContext = mContext;
		mLayoutInflater =LayoutInflater.from(mContext);
		
		
	}

	@Override
	public int getCount() {
		// TODO Auto-generated method stub
		return mDi100s.size();
	}

	@Override
	public Object getItem(int arg0) {
		// TODO Auto-generated method stub
		return mDi100s.get(arg0);
	}

	@Override
	public long getItemId(int arg0) {
		// TODO Auto-generated method stub
		return arg0;
	}

	@Override
	public View getView(int position, View convertView, ViewGroup parent) {
		// TODO Auto-generated method stub
		View view =convertView;
		ViewHolder holder =null;
		if(view == null){
			view =mLayoutInflater.inflate(R.layout.layout_content_item, null);
			holder =new ViewHolder();
			holder.layout_content_item_EX_info= (TextView) view.findViewById(R.id.layout_content_item_EX_info);
			holder.layout_content_item_EX_item= (TextView) view.findViewById(R.id.layout_content_item_EX_item);
			holder.layout_content_item_EX_name_num=(TextView) view.findViewById(R.id.layout_content_item_EX_name_num);
			holder.layout_content_item_EX_State= (TextView) view.findViewById(R.id.layout_content_item_EX_State);
			view.setTag(holder);
		}else{
			holder =(ViewHolder)view.getTag();
		}
//		final KuaiDi100 mKuaiDi100=mDi100s.get(position);
		
		ExString extostring=new ExString();
		String to;
		to=extostring.ExCodToString(mDi100s.get(position).getCom().toString());
		
		holder.layout_content_item_EX_name_num.setText(to+" 单号:"+mDi100s.get(0).getNu());
		
		
		
		holder.layout_content_item_EX_info.setText(mDi100s.get(position).getData().get(0).getContext());
		holder.layout_content_item_EX_item.setText(mDi100s.get(position).getData().get(0).getTime());
		holder.layout_content_item_EX_State.setText(new ExState().State(mDi100s.get(position).getData().get(0).getContext()));
		
		
		return view;
	}
	
	
	class ViewHolder{
		TextView layout_content_item_EX_name_num,layout_content_item_EX_item,layout_content_item_EX_State,layout_content_item_EX_info;
	}

}
