package com.wode.myexample.push;

import java.util.List;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.util.Log;
import android.widget.Toast;

import com.baidu.android.pushservice.PushConstants;
import com.baidu.frontia.api.FrontiaPushMessageReceiver;
import com.wode.myexample.dao.MyDao;

public class MyPushMessageReceiver extends FrontiaPushMessageReceiver{


//	@Override
//	public void onReceive(Context context, Intent intent) {
//		if (intent.getAction().equals(PushConstants.ACTION_MESSAGE)) {
//
//		} else if (intent.getAction().equals(PushConstants.ACTION_RECEIVE)) {
//
//		} else if (intent.getAction().equals(	
//			PushConstants.ACTION_RECEIVER_NOTIFICATION_CLICK)) {
//			Log.i(TAG, "title = " + intent.getStringExtra(PushConstants.EXTRA_NOTIFICATION_TITLE));
//			Log.i(TAG, "content = " + intent.getStringExtra(PushConstants.EXTRA_NOTIFICATION_CONTENT));
//		}
//	}
	@Override
    public void onBind(Context context, int errorCode, String appid,
            String userId, String channelId, String requestId) {
        String responseString = "onBind errorCode=" + errorCode + " appid="
                + appid + " userId=" + userId + " channelId=" + channelId
                + " requestId=" + requestId;
        
        
        new MyDao().PushDao(userId, channelId, context);
        
        Log.e("usere id", responseString);

        // 绑定成功，设置已绑定flag，可以有效的减少不必要的绑定请求
        if (errorCode == 0) {
            Utils.setBind(context, true);
        }
        // Demo更新界面展示代码，应用请在这里加入自己的处理逻辑
    }

	@Override
	public void onDelTags(Context arg0, int arg1, List<String> arg2,
			List<String> arg3, String arg4) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void onListTags(Context arg0, int arg1, List<String> arg2,
			String arg3) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void onMessage(Context arg0, String arg1, String arg2) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void onNotificationClicked(Context arg0, String arg1, String arg2,
			String arg3) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void onSetTags(Context arg0, int arg1, List<String> arg2,
			List<String> arg3, String arg4) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void onUnbind(Context arg0, int arg1, String arg2) {
		// TODO Auto-generated method stub
		
	}
}
