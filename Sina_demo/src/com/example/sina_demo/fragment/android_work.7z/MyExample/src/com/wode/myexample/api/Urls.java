package com.wode.myexample.api;

public class Urls {
	public final static String PROTOCOL = "http";
//	public final static String HOST = "192.168.10.253";
	public final static String HOST = "beijingwodekeji.eicp.net";
//	public final static String HOST = "vsxiaobai.oicp.net";
	
//	public final static String PORT = "8080";
	public final static String API = "/wode/";
	
	public final static String WEB_SERVER_PATH = PROTOCOL + "://" + HOST + ":" +API;
	/*
	 * 注册
	 */
	public final static String USERREGISTER="user!userRegister?";
	/*
	 * 校验用户
	 */
	public final static String CHECKNAME="user!checkName?";
	/*
	 * 用户登入
	 */
	public final static String USERLOGIN="user!userLogin?";
	
	public final static String MOB_APP_SECRET = "a2580a8e9b2358d7152b34a655e5985d";
	public final static String MOB_APP_KEY = "2b7991941904";
	
	
	public final static String BD_PUSH_APP_KEY="9Xq4urdMw3DcYTLEMNT0dIcl";
	
}
