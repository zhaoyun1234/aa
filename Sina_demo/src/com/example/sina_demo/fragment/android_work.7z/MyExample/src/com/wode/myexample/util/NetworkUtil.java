package com.wode.myexample.util;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;

import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.HttpStatus;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.params.BasicHttpParams;
import org.apache.http.params.HttpConnectionParams;
import org.apache.http.params.HttpParams;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.util.Log;

public class NetworkUtil {
	/**
	 * 判断网络连接状态
	 * @param context
	 */
	public static boolean isNetAvailable(Context context){
		//获取网络连接管理器
		ConnectivityManager connect = (ConnectivityManager) context.getSystemService(Context.CONNECTIVITY_SERVICE);
		//需要权限 android.permission.ACCESS_NETWORK_STATE
		NetworkInfo mNetInfo =connect.getActiveNetworkInfo();
		if(mNetInfo == null || !mNetInfo.isAvailable()){
			return false;
		}
		// 获取网络连接类型： mNetworkInfo.getType()
		return true;
	}
	/**
	 * 使用HttpURLConnection通过网络获取Json串
	 * @param urlStr
	 * @return
	 */
	public static String getJsonStrFormUrl(String urlStr){
		String result =null;
		BufferedReader br =null;
		try {
			URL url =new URL(urlStr);
			HttpURLConnection conn =(HttpURLConnection) url.openConnection();
			conn.setConnectTimeout(12*1000);
			conn.setReadTimeout(12*1000);
			if(conn.getResponseCode() ==200){
			br =new BufferedReader(new InputStreamReader(conn.getInputStream()));
			StringBuilder builder =new StringBuilder();
			String str =null;
			while((str =br.readLine()) !=null){
				builder.append(str);
			}
			result =builder.toString();
			}else{
				Log.d("TAG", "服务器响应异常");
			}
		} catch (MalformedURLException e) {
			// TODO Auto-generated catch block
			Log.d("TAG", e.getMessage()+"");
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			Log.d("TAG", e.getMessage()+"");
			e.printStackTrace();
		}finally{
			try {
				if(br !=null){
				br.close();
				br =null;
				}
			} catch (IOException e) {
				// TODO Auto-generated catch block

				
				e.printStackTrace();
			}
		}
		return result;
	}
	/**
	 * 使用HttpClient的get方式通过网络获取图片
	 * @param imageUrl
	 * @return
	 */
	public static Bitmap getBitmapFromUrl(String imageUrl){
		Bitmap result =null;
		HttpGet request =new HttpGet(imageUrl);
		HttpParams connParams =new BasicHttpParams();
		HttpConnectionParams.setConnectionTimeout(connParams, 5*1000);
		HttpConnectionParams.setSoTimeout(connParams, 5*1000);
		HttpClient client =new DefaultHttpClient(connParams);
		try {
			HttpResponse resp =client.execute(request);
			if(resp.getStatusLine().getStatusCode() ==HttpStatus.SC_OK){
				HttpEntity entity = resp.getEntity();
				result =BitmapFactory.decodeStream(entity.getContent());
			}else{
				Log.d("TAG", "服务器响应异常");
			}
		} catch (ClientProtocolException e) {
			// TODO Auto-generated catch block
			Log.d("TAG", e.getMessage()+"");
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			Log.d("TAG", e.getMessage()+"");
			e.printStackTrace();
		}
		return result;
	}
	/**
	 * 使用HttpClient的get方法通过网络获取输入流
	 * @param urlStr
	 * @return
	 */
	public static InputStream getInputStreamFromUrl(String urlStr){
		InputStream is =null;
		HttpGet request =new HttpGet(urlStr);
		HttpParams connParams =new BasicHttpParams();
		HttpConnectionParams.setConnectionTimeout(connParams, 5*1000);
		HttpConnectionParams.setSoTimeout(connParams, 5*1000);
		HttpClient client =new DefaultHttpClient(connParams);
		try {
			HttpResponse resp =client.execute(request);
			if(resp.getStatusLine().getStatusCode() ==HttpStatus.SC_OK){
				HttpEntity entity =resp.getEntity();
				is =entity.getContent();
			}else{
				Log.d("TAG", "服务器响应异常");
			}
		} catch (ClientProtocolException e) {
			// TODO Auto-generated catch block
			Log.d("TAG", e.getMessage()+"");
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			Log.d("TAG", e.getMessage()+"");
			e.printStackTrace();
		}
		return is;
	}
}
