package com.wode.myexample.util;

import java.io.Serializable;

/**
 * 快递代码转快递名字
 * @author KiSs_DaDa
 * @data 2014-11-1
 */
public class ExString implements Serializable{
	private String ExCod;
	private String ExString;
	public ExString(String exCod) {
		super();
		ExCod = exCod;
	}

	public ExString() {
		super();
	}

	public String getExCod() {
		return ExCod;
	}

	public void setExCod(String exCod) {
		ExCod = exCod;
	}

	public String getExString() {
		return ExString;
	}

	public void setExString(String exString) {
		ExString = exString;
	}

	@Override
	public String toString() {
		return "ExString [ExCod=" + ExCod + ", ExString=" + ExString + "]";
	}
	public String ExCodToString(String Cod){
		
		if (Cod.equals("aae")) {
			ExString="aae全球专递";
		} else if (Cod.equals("anjie")) {
			ExString="安捷快递";
		} else if (Cod.equals("biaojikuaidi")) {
			ExString="彪记快递";
		} else if (Cod.equals("baifudongfang")) {
			ExString="百福东方国际物流";
		} else if (Cod.equals("coe")) {
			ExString="中国东方";
		} else if (Cod.equals("changyuwuliu")) {
			ExString="长宇物流";
		} else if (Cod.equals("datianwuliu")) {
			ExString="大田物流";
		} else if (Cod.equals("debangwuliu")) {
			ExString="德邦物流";
		} else if (Cod.equals("dhl")) {
			ExString="dhl";
		} else if (Cod.equals("dpex")) {
			ExString="dpex";
		} else if (Cod.equals("dsukuaidi")) {
			ExString="d速快递";
		} else if (Cod.equals("disifang")) {
			ExString="递四方";
		} else if (Cod.equals("ems")) {
			ExString="ems快递";
		} else if (Cod.equals("fedex")) {
			ExString="fedex";
		} else if (Cod.equals("feikangda")) {
			ExString="飞康达物流";
		} else if (Cod.equals("fenghuangkuaidi")) {
			ExString="凤凰快递";
		} else if (Cod.equals("feikuaida")) {
			ExString="飞快达";
		} else if (Cod.equals("guotongkuaidi")) {
			ExString="国通快递";
		} else if (Cod.equals("ganzhongnengda")) {
			ExString="港中能达物流";
		} else if (Cod.equals("guangdongyouzhengwuliu")) {
			ExString="广东邮政物流";
		} else if (Cod.equals("gongsuda")) {
			ExString="共速达";
		} else if (Cod.equals("huitongkuaidi")) {
			ExString="汇通快运";
		} else if (Cod.equals("hengluwuliu")) {
			ExString="恒路物流";
		} else if (Cod.equals("huaxialongwuliu")) {
			ExString="华夏龙物流";
		} else if (Cod.equals("haihongwangsong")) {
			ExString="海红";
		} else if (Cod.equals("haiwaihuanqiu")) {
			ExString="海外环球";
		} else if (Cod.equals("jiayiwuliu")) {
			ExString="佳怡物流";
		} else if (Cod.equals("jinguangsudikuaijian")) {
			ExString="京广速递";
		} else if (Cod.equals("jixianda")) {
			ExString="急先达";
		} else if (Cod.equals("jjwl")) {
			ExString="佳吉物流";
		} else if (Cod.equals("jymwl")) {
			ExString="加运美物流";
		} else if (Cod.equals("jindawuliu")) {
			ExString="金大物流";
		} else if (Cod.equals("jialidatong")) {
			ExString="嘉里大通";
		} else if (Cod.equals("jykd")) {
			ExString="晋越快递";
		} else if (Cod.equals("kuaijiesudi")) {
			ExString="快捷速递";
		} else if (Cod.equals("lianb")) {
			ExString="联邦快递";
		} else if (Cod.equals("lianhaowuliu")) {
			ExString="联昊通物流";
		} else if (Cod.equals("longbanwuliu")) {
			ExString="龙邦物流";
		} else if (Cod.equals("lijisong")) {
			ExString="立即送";
		} else if (Cod.equals("lejiedi")) {
			ExString="乐捷递";
		} else if (Cod.equals("minghangkuaidi")) {
			ExString="民航快递";
		} else if (Cod.equals("meiguokuaidi")) {
			ExString="美国快递";
		} else if (Cod.equals("menduimen")) {
			ExString="门对门";
		} else if (Cod.equals("ocs")) {
			ExString="OCS";
		} else if (Cod.equals("peisihuoyunkuaidi")) {
			ExString="配思货运";
		} else if (Cod.equals("quanchenkuaidi")) {
			ExString="全晨快递";
		} else if (Cod.equals("quanfengkuaidi")) {
			ExString="全峰快递";
		} else if (Cod.equals("quanjitong")) {
			ExString="全际通物流";
		} else if (Cod.equals("quanritongkuaidi")) {
			ExString="全日通快递";
		} else if (Cod.equals("quanyikuaidi")) {
			ExString="全一快递";
		} else if (Cod.equals("rufengda")) {
			ExString="如风达";
		} else if (Cod.equals("santaisudi")) {
			ExString="三态速递";
		} else if (Cod.equals("shenghuiwuliu")) {
			ExString="盛辉物流";
		} else if (Cod.equals("shentong")) {
			ExString="申通";
		} else if (Cod.equals("shunfeng")) {
			ExString="顺丰";
		} else if (Cod.equals("sue")) {
			ExString="速尔物流";
		} else if (Cod.equals("shengfeng")) {
			ExString="盛丰物流";
		} else if (Cod.equals("saiaodi")) {
			ExString="赛澳递";
		} else if (Cod.equals("tiandihuayu")) {
			ExString="天地华宇";
		} else if (Cod.equals("tiantian")) {
			ExString="天天快递";
		} else if (Cod.equals("tnt")) {
			ExString="tnt";
		} else if (Cod.equals("ups")) {
			ExString="ups";
		} else if (Cod.equals("wanjiawuliu")) {
			ExString="万家物流";
		} else if (Cod.equals("wenjiesudi")) {
			ExString="文捷航空速递";
		} else if (Cod.equals("wuyuan")) {
			ExString="伍圆";
		} else if (Cod.equals("wxwl")) {
			ExString="万象物流";
		} else if (Cod.equals("xinbangwuliu")) {
			ExString="新邦物流";
		} else if (Cod.equals("xinfengwuliu")) {
			ExString="信丰物流";
		} else if (Cod.equals("yafengsudi")) {
			ExString="亚风速递";
		} else if (Cod.equals("yibangwuliu")) {
			ExString="一邦速递";
		} else if (Cod.equals("youshuwuliu")) {
			ExString="优速物流";
		} else if (Cod.equals("youzhengguonei")) {
			ExString="邮政包裹挂号信";
		} else if (Cod.equals("youzhengguoji")) {
			ExString="邮政国际包裹挂号信";
		} else if (Cod.equals("yuanchengwuliu")) {
			ExString="远成物流";
		} else if (Cod.equals("yuantong")) {
			ExString="圆通速递";
		} else if (Cod.equals("yuanweifeng")) {
			ExString="源伟丰快递";
		} else if (Cod.equals("yuanzhijiecheng")) {
			ExString="元智捷诚快递";
		} else if (Cod.equals("yunda")) {
			ExString="韵达快运";
		} else if (Cod.equals("yuntongkuaidi")) {
			ExString="运通快递";
		} else if (Cod.equals("yuefengwuliu")) {
			ExString="越丰物流";
		} else if (Cod.equals("yad")) {
			ExString="源安达";
		} else if (Cod.equals("yinjiesudi")) {
			ExString="银捷速递";
		} else if (Cod.equals("zhaijisong")) {
			ExString="宅急送";
		} else if (Cod.equals("zhongtiekuaiyun")) {
			ExString="中铁快运";
		} else if (Cod.equals("zhongtong")) {
			ExString="中通速递";
		} else if (Cod.equals("zhongyouwuliu")) {
			ExString="中邮物流";
		} else if (Cod.equals("zhongxinda")) {
			ExString="忠信达";
		} else if (Cod.equals("zhimakaimen")) {
			ExString="芝麻开门";
		} else {
			ExString=Cod;
		}

		
		
		
		
		return ExString;
	}

}
