package com.wode.myexample.dao;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteDatabase.CursorFactory;
import android.database.sqlite.SQLiteOpenHelper;

public class DateBaseHelper extends SQLiteOpenHelper{

	public DateBaseHelper(Context context, String name, CursorFactory factory,
			int version) {
		super(context, "myexamole", factory, 1);
		// TODO Auto-generated constructor stub
	}
	public DateBaseHelper(Context context) {
		super(context, "myexamole", null, 1);
		// TODO Auto-generated constructor stub
	}
	
	
	@Override
	public void onCreate(SQLiteDatabase db) {
		// TODO Auto-generated method stub
		
		String sql1 = "create table user(_id Integer primary key autoincrement, username varchar(20) not null UNIQUE, userpwd varchar(10) not null,userid varchar(100) not null,channelid varchar(100) not null,imsi varchar(100) not null,ser int not null)";
		db.execSQL(sql1);
		String sql2="create table push(_id Integer primary key autoincrement, userid varchar(100) not null,channelid varchar(100) not null)";
		db.execSQL(sql2);
	}

	@Override
	public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
		// TODO Auto-generated method stub
		
	}

}
