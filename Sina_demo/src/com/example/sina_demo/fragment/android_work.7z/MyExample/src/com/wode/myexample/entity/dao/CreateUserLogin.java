package com.wode.myexample.entity.dao;

import java.io.Serializable;

public class CreateUserLogin implements Serializable{
	private int id;
	private String num;
	private String login;
	public CreateUserLogin() {
		super();
	}
	public CreateUserLogin(int id, String num, String login) {
		super();
		this.id = id;
		this.num = num;
		this.login = login;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getNum() {
		return num;
	}
	public void setNum(String num) {
		this.num = num;
	}
	public String getLogin() {
		return login;
	}
	public void setLogin(String login) {
		this.login = login;
	}
	@Override
	public String toString() {
		return "CreateUserLogin [id=" + id + ", num=" + num + ", login="
				+ login + "]";
	}
	
	

}
