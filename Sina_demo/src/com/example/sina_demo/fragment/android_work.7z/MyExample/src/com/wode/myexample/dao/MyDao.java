package com.wode.myexample.dao;

import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.util.Log;

public class MyDao {
	DateBaseHelper dh = null;
	Cursor cursor = null;

	public void PushDao(String userid, String channelid, Context mContext) {

		dh = new DateBaseHelper(mContext);
		SQLiteDatabase sd = dh.getWritableDatabase();
		String delpush = "delete from push";
		sd.execSQL(delpush);
		String sql = "insert into push values(1,'" + userid + "','" + channelid
				+ "')";
		sd.execSQL(sql);

		String sqls = "select * from push";
		cursor = sd.rawQuery(sqls, null);

		while (cursor.moveToNext()) {
			int idCursor = cursor.getColumnIndex("_id");
			int mid = cursor.getInt(idCursor);

			int useridCursor = cursor.getColumnIndex("userid");
			String muserid = cursor.getString(useridCursor);

			int channelidCursor = cursor.getColumnIndex("channelid");
			String mhannelid = cursor.getString(channelidCursor);

			Log.e("SQL-push", mid + "-" + muserid + "-" + mhannelid);

		}
	}

	public void LoginDao(String username, String userpwd, String channelid,
			String userid, String imsi,Context mContext) {
		dh = new DateBaseHelper(mContext);
		SQLiteDatabase sd = dh.getWritableDatabase();
		String sql_dell = "delete from user";
		sd.execSQL(sql_dell);

		String sql = "insert into user values(1,'" + username + "','" + userpwd
				+ "','" + userid + "','" + channelid + "','" + imsi + "',1)";

		sd.execSQL(sql);
		String sqls = "select * from user";
		cursor = sd.rawQuery(sqls, null);
		while (cursor.moveToNext()) {
			int idCursor = cursor.getColumnIndex("_id");
			int mid = cursor.getInt(idCursor);

			int usernameCursor = cursor.getColumnIndex("username");
			String musername = cursor.getString(usernameCursor);

			int userpwdCursor = cursor.getColumnIndex("userpwd");
			String muserpwd = cursor.getString(userpwdCursor);

			int useridCursor = cursor.getColumnIndex("userid");
			String muserid = cursor.getString(useridCursor);

			int channelidCursor = cursor.getColumnIndex("channelid");
			String mchannelid = cursor.getString(channelidCursor);

			int imsiCursor = cursor.getColumnIndex("imsi");
			String mimsi = cursor.getString(imsiCursor);

			int serCursor = cursor.getColumnIndex("ser");
			int mser = cursor.getInt(serCursor);

			Log.e("Login sql", mid + "|" + musername + "|" + muserpwd + "|"
					+ muserid + "|" + mchannelid + "|" + mimsi + "|" + mser);

		}
	}
	public String LoginStateDao(Context mContext){
		dh = new DateBaseHelper(mContext);
		SQLiteDatabase sd = dh.getWritableDatabase();
		String sqls = "select count(*) from user";
		cursor = sd.rawQuery(sqls, null);
		String count= "0";
		while (cursor.moveToNext()) {
			int countCursor=cursor.getColumnIndex("count(*)");
			count=cursor.getString(countCursor);			
		}
		Log.e("LoginStateDao",count);
		return count;
	}
	public void Exitlogin(Context mContext){
		
		dh = new DateBaseHelper(mContext);
		SQLiteDatabase sd = dh.getWritableDatabase();
		String sql_dell = "delete from user";
		sd.execSQL(sql_dell);
		
	}
	
}