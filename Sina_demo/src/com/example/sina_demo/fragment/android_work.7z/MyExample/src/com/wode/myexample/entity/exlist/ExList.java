package com.wode.myexample.entity.exlist;

import java.io.Serializable;
import java.util.List;

import com.wode.myexample.entity.kuaidi100.KuaiDi100;

public class ExList implements Serializable{

	private KuaiDi100 di100s;

	public ExList() {
		super();
	}

	public ExList(KuaiDi100 di100s) {
		super();
		this.di100s = di100s;
	}

	public KuaiDi100 getDi100s() {
		return di100s;
	}

	public void setDi100s(KuaiDi100 di100s) {
		this.di100s = di100s;
	}

	@Override
	public String toString() {
		return "ExList [di100s=" + di100s + "]";
	}

}
