package com.wode.myexample.entity.kuaidi100;

import java.io.Serializable;
import java.util.List;

import com.wode.myexample.entity.kuaidi100.data.Data;

public class KuaiDi100 implements Serializable{
    private String message;
    private String nu;
    private String ischeck;
    private String com;
    private String status;
    private String condition;
    private String state;
    private List<Data> data;
    private String companytype;
    private String updatetime;
    private String signname;
    private String codenumber;
    private String signedtime;
	public KuaiDi100() {
		super();
	}
	public KuaiDi100(String message, String nu, String ischeck, String com,
			String status, String condition, String state, List<Data> data,
			String companytype, String updatetime, String signname,
			String codenumber, String signedtime) {
		super();
		this.message = message;
		this.nu = nu;
		this.ischeck = ischeck;
		this.com = com;
		this.status = status;
		this.condition = condition;
		this.state = state;
		this.data = data;
		this.companytype = companytype;
		this.updatetime = updatetime;
		this.signname = signname;
		this.codenumber = codenumber;
		this.signedtime = signedtime;
	}
	public String getMessage() {
		return message;
	}
	public void setMessage(String message) {
		this.message = message;
	}
	public String getNu() {
		return nu;
	}
	public void setNu(String nu) {
		this.nu = nu;
	}
	public String getIscheck() {
		return ischeck;
	}
	public void setIscheck(String ischeck) {
		this.ischeck = ischeck;
	}
	public String getCom() {
		return com;
	}
	public void setCom(String com) {
		this.com = com;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getCondition() {
		return condition;
	}
	public void setCondition(String condition) {
		this.condition = condition;
	}
	public String getState() {
		return state;
	}
	public void setState(String state) {
		this.state = state;
	}
	public List<Data> getData() {
		return data;
	}
	public void setData(List<Data> data) {
		this.data = data;
	}
	public String getCompanytype() {
		return companytype;
	}
	public void setCompanytype(String companytype) {
		this.companytype = companytype;
	}
	public String getUpdatetime() {
		return updatetime;
	}
	public void setUpdatetime(String updatetime) {
		this.updatetime = updatetime;
	}
	public String getSignname() {
		return signname;
	}
	public void setSignname(String signname) {
		this.signname = signname;
	}
	public String getCodenumber() {
		return codenumber;
	}
	public void setCodenumber(String codenumber) {
		this.codenumber = codenumber;
	}
	public String getSignedtime() {
		return signedtime;
	}
	public void setSignedtime(String signedtime) {
		this.signedtime = signedtime;
	}
	@Override
	public String toString() {
		return "KuaiDi100 [message=" + message + ", nu=" + nu + ", ischeck="
				+ ischeck + ", com=" + com + ", status=" + status
				+ ", condition=" + condition + ", state=" + state + ", data="
				+ data + ", companytype=" + companytype + ", updatetime="
				+ updatetime + ", signname=" + signname + ", codenumber="
				+ codenumber + ", signedtime=" + signedtime + "]";
	}
    
    
    

}
