package com.wode.myexample;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.SocketTimeoutException;
import java.net.URL;
import java.util.List;
import java.util.Properties;

import cn.smssdk.EventHandler;
import cn.smssdk.SMSSDK;

import com.google.gson.Gson;
import com.lidroid.xutils.HttpUtils;
import com.wode.myexample.api.Urls;
import com.wode.myexample.entity.checkName.CheckName;
import com.wode.myexample.entity.userRegister.UserRegister;
import com.wode.myexample.util.ClickFilter;
import com.wode.myexample.util.NetworkUtil;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.telephony.TelephonyManager;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
/**
 * 注册页面
 * @author KiSs_DaDa
 * @data 2014-10-29
 */
public class ActivityRegister extends Activity implements OnClickListener {
	// 获取 验证 获取国家
	private Button sensmsButton, verificationButton, countryButton;
	// 国家信息 状态信息
	// private TextView countryTextView,textView2;
	// 电话号 验证码
	private EditText phonEditText, verEditText, pw1, pw2;
	// 填写从短信SDK应用后台注册得到的APPKEY
	private static String APPKEY = Urls.MOB_APP_KEY;
	// 填写从短信SDK应用后台注册得到的APPSECRET
	private static String APPSECRET = Urls.MOB_APP_SECRET;
	public String phString;
	public String imsi;
	private final String TAG = this.getClass().getSimpleName();

	private final int DATA_SUCCESS = 1;
	private final int HTTP_ERROR = 2;
	private final int NET_ERROR = 3;
	private final int NET_REG = 4;

	private final String URL = Urls.WEB_SERVER_PATH + Urls.CHECKNAME;
	private Context mContext;
	private int a = 0;
	private Handler mHandler = new Handler() {
		@Override
		public void handleMessage(Message msg) {
			// TODO Auto-generated method stub
			super.handleMessage(msg);
			switch (msg.what) {
			case DATA_SUCCESS:
				CheckName mCheckName = (CheckName) msg.obj;
				// adapter =new CateAdapter(listView, cate, mContext);
				// listView.setAdapter(adapter);
				Log.e(TAG, mCheckName.toString());
				if (mCheckName.getStatus() == 2) {
					Toast.makeText(mContext, mCheckName.getMessage(),
							Toast.LENGTH_SHORT).show();
					a = 0;
				} else if (mCheckName.getStatus() == 3) {
					Toast.makeText(mContext, mCheckName.getMessage(),
							Toast.LENGTH_SHORT).show();
					a = 0;
				} else if (mCheckName.getStatus() == 4) {
					Toast.makeText(mContext, mCheckName.getMessage(),
							Toast.LENGTH_SHORT).show();
					a = 0;
				} else if (mCheckName.getStatus() == 1) {

					SMSSDK.getVerificationCode("86", phonEditText.getText()
							.toString());

					Toast.makeText(mContext, "号码可注册已发送验证码", Toast.LENGTH_SHORT)
							.show();

					a = 1;
				}
				break;
			case HTTP_ERROR:
				Toast.makeText(mContext, "获取数据失败", Toast.LENGTH_SHORT).show();
				break;
			case NET_ERROR:
				Toast.makeText(mContext, "网络无连接", Toast.LENGTH_SHORT).show();
				break;
			case NET_REG:
				UserRegister mRegister = (UserRegister) msg.obj;

				if (mRegister.getStatus() == 1) {
					Toast.makeText(mContext, mRegister.getMessage(),
							Toast.LENGTH_SHORT).show();
				} else if (mRegister.getStatus() == 2) {
					Toast.makeText(mContext, mRegister.getMessage(),
							Toast.LENGTH_SHORT).show();
				} else if (mRegister.getStatus() == 3) {
					Toast.makeText(mContext, mRegister.getMessage(),
							Toast.LENGTH_SHORT).show();
				} else if (mRegister.getStatus() == 4) {
					Toast.makeText(mContext, mRegister.getMessage(),
							Toast.LENGTH_SHORT).show();
				}

				Intent intent = new Intent(ActivityRegister.this,
						MainActivity.class);
				startActivity(intent);
				overridePendingTransition(R.anim.go_in, R.anim.go_out);

				break;
			}
		}
	};

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		setContentView(R.layout.layout_register);
		mContext = this;
		phonEditText = (EditText) findViewById(R.id.layout_register_user);
		verEditText = (EditText) findViewById(R.id.layout_register_FM_EditText);

		sensmsButton = (Button) findViewById(R.id.layout_register_FM_btn);
		verificationButton = (Button) findViewById(R.id.layout_register_registerBtn);

		pw1 = (EditText) findViewById(R.id.layout_register_pw1);
		pw2 = (EditText) findViewById(R.id.layout_register_pw2);

		TelephonyManager mTelephonyMgr = (TelephonyManager) getSystemService(Context.TELEPHONY_SERVICE);
		imsi = mTelephonyMgr.getSubscriberId();

		SMSSDK.initSDK(this, APPKEY, APPSECRET);

		sensmsButton.setOnClickListener(this);
		verificationButton.setOnClickListener(this);

		EventHandler eh = new EventHandler() {

			@Override
			public void afterEvent(int event, int result, Object data) {

				Message msg = new Message();
				msg.arg1 = event;
				msg.arg2 = result;
				msg.obj = data;
				handler.sendMessage(msg);
			}

		};
		SMSSDK.registerEventHandler(eh);
	}

	// 点击事件
	@Override
	public void onClick(View v) {
		// TODO Auto-generated method stub
		switch (v.getId()) {
		case R.id.layout_register_FM_btn:// 获取验证码
			if (!TextUtils.isEmpty(phonEditText.getText().toString())) {
				if (phonEditText.getText().toString().length() == 11) {

					new Thread(new Runnable() {

						@Override
						public void run() {
							// TODO Auto-generated method stub
							if (NetworkUtil.isNetAvailable(mContext)) {
								Log.e(TAG, URL
										+ phonEditText.getText().toString());
								String jsonStr = NetworkUtil
										.getJsonStrFormUrl(URL
												+ "phoneNumber="
												+ phonEditText.getText()
														.toString());
								if (jsonStr != null) {
									CheckName mCheckName = parseNews(jsonStr);
									Message msg = mHandler.obtainMessage(
											DATA_SUCCESS, mCheckName);
									mHandler.sendMessage(msg);
								} else {
									mHandler.sendEmptyMessage(HTTP_ERROR);
								}
							} else {
								mHandler.sendEmptyMessage(NET_ERROR);
							}
						}
					}).start();
				} else {

				}
				// SMSSDK.getVerificationCode("86",phonEditText.getText().toString());
				// phString = phonEditText.getText().toString();
			} else {
				Toast.makeText(this, "电话不能为空", 1).show();
			}

			break;
		case R.id.layout_register_registerBtn:// 校验验证码
			if (!TextUtils.isEmpty(verEditText.getText().toString())) {
				SMSSDK.submitVerificationCode("86", phString, verEditText
						.getText().toString());

			} else {
				Toast.makeText(this, "验证码不能为空", 1).show();
			}
			break;
		default:
			break;
		}
	}

	public CheckName parseNews(String jsonStr) {
		Gson gson = new Gson();
		// Type type =new TypeToken<List<Cate>>(){}.getType();

		return gson.fromJson(jsonStr, CheckName.class);
	}

	public UserRegister parseNews1(String jsonStr) {
		Gson gson = new Gson();
		// Type type =new TypeToken<List<Cate>>(){}.getType();

		return gson.fromJson(jsonStr, UserRegister.class);
	}

	Handler handler = new Handler() {

		@Override
		public void handleMessage(Message msg) {
			// TODO Auto-generated method stub
			super.handleMessage(msg);
			int event = msg.arg1;
			int result = msg.arg2;
			Object data = msg.obj;
			Log.e("event", "event=" + event);
			if (result == SMSSDK.RESULT_COMPLETE) {
				// 短信注册成功后，返回MainActivity,然后提示新好友
				if (event == SMSSDK.EVENT_SUBMIT_VERIFICATION_CODE) {// 提交验证码成功
				// Toast.makeText(getApplicationContext(), "提交验证码成功",
				// Toast.LENGTH_SHORT).show();
					// textView2.setText("提交验证码成功");

				} else if (event == SMSSDK.EVENT_GET_VERIFICATION_CODE) {
					Toast.makeText(getApplicationContext(), "验证码已经发送",
							Toast.LENGTH_SHORT).show();
					sensmsButton.setText("验证码已经发送");
					// textView2.setText("验证码已经发送");
				}
			} else {
				((Throwable) data).printStackTrace();
			}

			if (a == 1) {
				if (pw1.getText().toString().equals(pw2.getText().toString())
						&& pw1.getText().length() <= 16
						& pw1.getText().length() >= 6) {

					new Thread(new Runnable() {

						@Override
						public void run() {
							// TODO Auto-generated method stub
							if (NetworkUtil.isNetAvailable(mContext)) {
								Log.e(TAG, URL
										+ phonEditText.getText().toString());
								String jsonStr1 = NetworkUtil
										.getJsonStrFormUrl(Urls.WEB_SERVER_PATH
												+ Urls.USERREGISTER
												+ "phoneNumber="
												+ phonEditText.getText()
														.toString()
												+ "&serialNumber=" + imsi
												+ "&passWord="
												+ pw2.getText().toString());
								Log.e(TAG, Urls.WEB_SERVER_PATH
										+ Urls.USERREGISTER + "phoneNumber="
										+ phonEditText.getText().toString()
										+ "&serialNumber=" + imsi
										+ "&passWord="
										+ pw2.getText().toString());
								if (jsonStr1 != null) {
									UserRegister mUserRegister = parseNews1(jsonStr1);
									Message msg = mHandler.obtainMessage(
											NET_REG, mUserRegister);
									mHandler.sendMessage(msg);
								} else {
									mHandler.sendEmptyMessage(HTTP_ERROR);
								}
							} else {
								mHandler.sendEmptyMessage(NET_ERROR);
							}
						}
					}).start();

				} else {
					// Toast.makeText(mContext, "密码格式不正确",
					// Toast.LENGTH_SHORT).show();

				}
			} else {

			}

		}

	};

	@Override
	protected void onDestroy() {
		// TODO Auto-generated method stub
		super.onDestroy();
		SMSSDK.unregisterAllEventHandler();
	}

}
