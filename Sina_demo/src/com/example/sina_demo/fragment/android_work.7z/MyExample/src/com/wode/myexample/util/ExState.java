package com.wode.myexample.util;

public class ExState {
	private String Context;

	public ExState() {
		super();
	}

	public ExState(String context) {
		super();
		Context = context;
	}

	public String getContext() {
		return Context;
	}

	public void setContext(String context) {
		Context = context;
	}

	@Override
	public String toString() {
		return "ExState [Context=" + Context + "]";
	}

	public String State(String Context) {

		if (Context.indexOf("已签收") > 0) {
			String a = "已签收";
			return a;
		} else if (Context.indexOf("正在派送") > 0) {
			String b = "正在派送";
			return b;
		} else {
			String c = "在路上";
			return c;
		}
	}
}
