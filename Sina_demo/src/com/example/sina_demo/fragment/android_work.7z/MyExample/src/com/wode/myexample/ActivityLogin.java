package com.wode.myexample;


import java.util.List;

import com.baidu.android.pushservice.PushConstants;
import com.baidu.android.pushservice.PushManager;
import com.google.gson.Gson;
import com.lidroid.xutils.DbUtils;
import com.lidroid.xutils.db.sqlite.Selector;
import com.wode.myexample.api.Urls;
import com.wode.myexample.dao.DateBaseHelper;
import com.wode.myexample.dao.MyDao;
import com.wode.myexample.entity.dao.CreateUserLogin;
import com.wode.myexample.entity.userRegister.UserRegister;
import com.wode.myexample.util.NetworkUtil;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.telephony.TelephonyManager;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class ActivityLogin extends Activity{
	
	
	
	
	public String imsi,channelId,userId;
	private Button loginbtn,regbtn,retrievebtn;
	private EditText username,userpw;
	private final String TAG = this.getClass().getSimpleName();
	private final int DATA_SUCCESS = 1;
	private final int HTTP_ERROR = 2;
	private final int NET_ERROR = 3;
	private final int NET_REG = 4;
	DateBaseHelper dh = null;
	Cursor cursor = null,cursor2=null;
	private Context mContext;
	private UserRegister mUserRegister;
	private CreateUserLogin mCreateUserLogin=new CreateUserLogin();
	private Handler mHandler = new Handler() {
		@Override
		public void handleMessage(Message msg) {
			// TODO Auto-generated method stub
			super.handleMessage(msg);
			switch (msg.what) {
			case DATA_SUCCESS:
				UserRegister mCheckName = (UserRegister) msg.obj;
				
				Log.e(TAG, mCheckName.toString());
				if (mCheckName.getStatus() == 2) {
					Toast.makeText(mContext, mCheckName.getMessage(),
							Toast.LENGTH_SHORT).show();
				} else if (mCheckName.getStatus() == 3) {
					Toast.makeText(mContext, mCheckName.getMessage(),
							Toast.LENGTH_SHORT).show();
				} else if (mCheckName.getStatus() == 4) {
					Toast.makeText(mContext, mCheckName.getMessage(),
							Toast.LENGTH_SHORT).show();
				} else if (mCheckName.getStatus() == 1) {
					
					
					
					
					mCreateUserLogin.setNum(username.getText().toString());
					mCreateUserLogin.setLogin("1");
					
					
					
					Toast.makeText(mContext, mCheckName.getMessage(),
							Toast.LENGTH_SHORT).show();	
					
					Intent intent = new Intent(ActivityLogin.this,
							MainActivity.class);
					startActivity(intent);
					overridePendingTransition(R.anim.go_in, R.anim.go_out);
					finish();
				}
				break;
			case HTTP_ERROR:
				Toast.makeText(mContext, "获取数据失败", Toast.LENGTH_SHORT).show();
				break;
			case NET_ERROR:
				Toast.makeText(mContext, "网络无连接", Toast.LENGTH_SHORT).show();
				break;

			}
		}
	};
	
	
	
	
	
	
	
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		setContentView(R.layout.layout_login);
		mContext = this;
		//模拟写入推送USER ID
		new MyDao().PushDao("1055685739374083688", "3502071907305713007", mContext);
		//获取IMSI
		TelephonyManager mTelephonyMgr = (TelephonyManager) getSystemService(Context.TELEPHONY_SERVICE);
		imsi = mTelephonyMgr.getSubscriberId();
		
//		 PushManager.startWork(mContext,PushConstants.LOGIN_TYPE_API_KEY, "9Xq4urdMw3DcYTLEMNT0dIcl");
		dh = new DateBaseHelper(mContext);
		SQLiteDatabase sd = dh.getWritableDatabase();
		String sqls = "select * from push";
		cursor = sd.rawQuery(sqls, null);

		while (cursor.moveToNext()) {
			int idCursor = cursor.getColumnIndex("_id");
			int mid = cursor.getInt(idCursor);

			int useridCursor = cursor.getColumnIndex("userid");
			userId = cursor.getString(useridCursor);

			int channelidCursor = cursor.getColumnIndex("channelid");
			channelId = cursor.getString(channelidCursor);

			Log.e("SQL-push", mid + "-" + userId + "-" + channelId);

		}
		
		
		
		inst();
		
		//注册跳转
		regbtn.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				Intent intent= new Intent(ActivityLogin.this,ActivityRegister.class);
				startActivity(intent);
				overridePendingTransition(R.anim.go_in, R.anim.go_out);
				
			}
		});
		//找回跳转
		retrievebtn.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				Intent intent= new Intent(ActivityLogin.this,ActivityRetrieve.class);
				startActivity(intent);
				overridePendingTransition(R.anim.go_in, R.anim.go_out);
			}
		});
		//登入跳转
		loginbtn.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				
				new Thread(new Runnable() {

					@Override
					public void run() {
						// TODO Auto-generated method stub
						if (NetworkUtil.isNetAvailable(mContext)) {
							Log.e(TAG, Urls.WEB_SERVER_PATH+Urls.USERLOGIN+"phoneNumber="+username.getText().toString()+"&serialNumber="+imsi+"&passWord="+userpw.getText().toString()+"&channelId="+channelId+"&userId="+userId);
							String jsonStr = NetworkUtil
									.getJsonStrFormUrl(Urls.WEB_SERVER_PATH+Urls.USERLOGIN+"phoneNumber="+username.getText().toString()+"&serialNumber="+imsi+"&passWord="+userpw.getText().toString()+"&channelId="+channelId+"&userId="+userId);
							if (jsonStr != null) {
								 mUserRegister = parseNews(jsonStr);
								 
								 
								 new MyDao().LoginDao(username.getText().toString(), userpw.getText().toString(), channelId, userId, imsi,mContext );
								 
								Message msg = mHandler.obtainMessage(
										DATA_SUCCESS, mUserRegister);
								mHandler.sendMessage(msg);
							} else {
								mHandler.sendEmptyMessage(HTTP_ERROR);
							}
						} else {
							mHandler.sendEmptyMessage(NET_ERROR);
						}
					}
				}).start();
				
				
				
				
			}
		});
		
	}
	private void inst() {
		// TODO Auto-generated method stub
		loginbtn=(Button) findViewById(R.id.layout_login_loginbtn);
		regbtn=(Button) findViewById(R.id.layout_login_regbtn);
		retrievebtn= (Button) findViewById(R.id.layout_login_retrievebtn);
		username= (EditText) findViewById(R.id.layout_login_username);
		userpw= (EditText) findViewById(R.id.layout_login_userpw);
	}

	public UserRegister parseNews(String jsonStr) {
		Gson gson = new Gson();
		// Type type =new TypeToken<List<Cate>>(){}.getType();

		return gson.fromJson(jsonStr, UserRegister.class);
	}
	
}
