package com.wode.myexample.util;

import java.lang.ref.SoftReference;
import java.util.HashMap;
import java.util.Map;

import android.content.Context;
import android.graphics.Bitmap;
import android.os.Handler;
import android.os.Message;
import android.widget.Toast;

public class ImageAsyncLoader {
	private Map<String,SoftReference<Bitmap>> mImageCache;
	private Context mContext;
	public ImageAsyncLoader(Context mContext) {
		super();
		mImageCache =new HashMap<String, SoftReference<Bitmap>>();
		this.mContext = mContext;
	}
	/**
	 *  实现图片异步加载的核心方法
	 * 1. 首先判断内存缓存中是否存在，存在则返回
	 * 2. 不存在，则判断本地缓存（SD卡）中是否存在，存在则返回
	 * 3. 不存在，则从网络上加载
	 * 当图片通过缓存得到，可以直接从方法返回值接受图片；
	 * 如果通过网络加载得到，则通过接口回调方法中的参数得到图片
	 * @param imageUrl
	 * @param imageCallback
	 * @return
	 */
	public Bitmap loadImage(final String imageUrl,final ImageCallback mImageCallback){
		Bitmap result =null;
		if(mImageCache.containsKey(imageUrl)){
			result =mImageCache.get(imageUrl).get();
			//虽然存在于内存缓存，但是有可能被GC回收掉
			if(result !=null){
				return result;
			}
		}
		final Handler mHandler =new Handler(){
			@Override
			public void handleMessage(Message msg) {
				// TODO Auto-generated method stub
				super.handleMessage(msg);
				switch (msg.what) {
				case 1:
					//调用接口回调方法，实际调用的是实现类的方法（运行时多态）
					mImageCallback.imageLoad((Bitmap)msg.obj, imageUrl);
					break;
				case 2:
					Toast.makeText(mContext, "图片获取失败！", Toast.LENGTH_SHORT).show();
					break;
				case 3:
					Toast.makeText(mContext, "网络不存在，请检查网络", Toast.LENGTH_SHORT).show();
					break;
				}
			}
		};
		new Thread(new Runnable() {
			
			@Override
			public void run() {
				// TODO Auto-generated method stub
				if(NetworkUtil.isNetAvailable(mContext)){
					Bitmap bitmap =NetworkUtil.getBitmapFromUrl(imageUrl);
					if(bitmap !=null){
						mImageCache.put(imageUrl, new SoftReference<Bitmap>(bitmap));
						Message msg =mHandler.obtainMessage(1,bitmap);
						mHandler.sendMessage(msg);
					}else{
						mHandler.sendEmptyMessage(2);
					}
				}else{
					mHandler.sendEmptyMessage(3);
				}
			}
		}).start();
		return null;
	}
	public interface ImageCallback{
		void imageLoad(Bitmap bitmap,String imageUrl);
	}
}