package com.wode.myexample.adapter;

import java.util.ArrayList;
import java.util.List;

import com.wode.myexample.R;
import com.wode.myexample.entity.kuaidi100.KuaiDi100;
import com.wode.myexample.entity.kuaidi100.data.Data;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ListView;
import android.widget.TextView;

public class FromAdapter extends BaseAdapter {
	private List<Data> mDatas = new ArrayList<Data>();
	private Context mContext;
	private LayoutInflater mLayoutInflater;

	public FromAdapter(ListView listView, List<Data> mDatas, Context mContext) {
		super();
		this.mDatas = mDatas;
		this.mContext = mContext;
		mLayoutInflater = LayoutInflater.from(mContext);
	}

	@Override
	public int getCount() {
		// TODO Auto-generated method stub
		return mDatas.size();
	}

	@Override
	public Object getItem(int position) {
		// TODO Auto-generated method stub
		return mDatas.get(position);
	}

	@Override
	public long getItemId(int position) {
		// TODO Auto-generated method stub
		return position;
	}

	@Override
	public View getView(int position, View convertView, ViewGroup parent) {
		// TODO Auto-generated method stub
		View view = convertView;
		ViewHolder holder = null;

		if (view == null) {
			view = mLayoutInflater.inflate(R.layout.layout_form_item, null);
			holder = new ViewHolder();
			holder.layout_form_item_info = (TextView) view
					.findViewById(R.id.layout_form_item_info);
			holder.layout_form_item_time = (TextView) view
					.findViewById(R.id.layout_form_item_time);
			view.setTag(holder);
		} else {
			holder = (ViewHolder) view.getTag();
		}
		holder.layout_form_item_info.setText(mDatas.get(position).getContext());
		holder.layout_form_item_time.setText(mDatas.get(position).getFtime());
		
		
		return view;
	}

	class ViewHolder {

		TextView layout_form_item_time, layout_form_item_info;

	}
}
