package com.wode.myexample.push;

import com.baidu.frontia.FrontiaApplication;

public class DemoApplication extends FrontiaApplication{
	@Override
	public void onCreate() {
		super.onCreate();
		FrontiaApplication.initFrontiaApplication(this);
	}
}
