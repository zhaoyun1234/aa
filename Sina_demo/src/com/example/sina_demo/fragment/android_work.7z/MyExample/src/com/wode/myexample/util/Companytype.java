package com.wode.myexample.util;

import java.util.ArrayList;
import java.util.List;

import android.util.Log;

public class Companytype {
	private final String EXC = "快递公司";
	private String url;
	private int a = 0;
	public List<String> zhengzhe(String num) {
		List<String> c= new ArrayList<String>();
		if (num.matches("^[0-9]{9,12}$")) {
			Log.e(EXC, "联昊通");
			a++;
			c.add("lianhaowuliu");
		} else {
		}
		if (num.matches("^[0-9]{12}$|^[0-9]{15}$")) {
			Log.e(EXC, "全峰快递");
			a++;
			c.add("quanfengkuaidi");
		} else {
		}
		if (num.matches("^\\d{12}$")) {
			Log.e(EXC, "全一快递");
			a++;
			c.add("quanyikuaidi");
		} else {
		}
		if (num.matches("^[A-Z]{2}[0-9]{9}[A-Z]{2}$")) {
			Log.e(EXC, "EMS");
			a++;
			c.add("ems");
		} else {
		}
		if (num.matches("^(0|1|2|3|5|6|7|8|E|D|F|G|V|W|e|d|f|g|v|w)[0-9]{9}$")) {
			Log.e(EXC, "圆通速递");
			a++;
			c.add("yuantong");
		} else {
		}
		if (num.matches("^((618|680|688|618|828|988|118|888|571|518|010|628|205|880|717|718|728|738|761|762|763|701|757|778)[0-9]{9})$|^((2008|2010|8050|7518)[0-9]{8})$")) {
			Log.e(EXC, "中通速递");
			a++;
			c.add("zhongtong");
		} else {
		}
		if (num.matches("^[a-zA-Z0-9]{10}$")) {
			Log.e(EXC, "宅急送");
			a++;
			c.add("zhaijisong");
		} else {
		}
		if (num.matches("^[\\s]*[0-9]{13}[\\s]*$")) {
			Log.e(EXC, "韵达快运");
			a++;
			c.add("yunda");
		} else {
		}
		if (num.matches("^[0-9]{14}$")) {
			Log.e(EXC, "海航天天快递");
			a++;
			c.add("tiantian");
		} else {
		}
		if (num.matches("^[0-9]{12}$")) {
			Log.e(EXC, "联邦快递");
			a++;
			c.add("lianb");
		} else {
		}
		if (num.matches("^[0-9]?[0-9]{7}$")) {
			Log.e(EXC, "德邦物流");
			a++;
			c.add("debangwuliu");
		} else {
		}
		if (num.matches("^(A|B|C|D|E|H|0)(D|X|[0-9])(A|[0-9])[0-9]{10}$|^(21|22|23|24|25|26|27|28|29|30|31|32|33|34|35|36|37|38|39)[0-9]{10}$")) {
			Log.e(EXC, "汇通快运");
			a++;
			c.add("huitongkuaidi");
		} else {
		}
		if (num.matches("^K[0-9]{13}$")) {
			Log.e(EXC, "中铁快运");
			a++;
			c.add("zhongtiekuaiyun");
		} else {
		}
		if (num.matches("[0-9]{12}$")) {
			Log.e(EXC, "顺丰速运");
			a++;
			c.add("shunfeng");
		} else {
		}
		if (num.matches("^(2|3|5|6|8|5|1)[0-9]{9}$")) {
			Log.e(EXC, "CCES");
			a++;
		} else {
		}
		if (num.matches("^(268|888|588|688|368|468|568|668|768|868|968)[0-9]{9}$|^(268|888|588|688|368|468|568|668|768|868|968)[0-9]{10}$|^(STO)[0-9]{10}$")) {
			Log.e(EXC, "申通E物流");
			a++;
			c.add("shentong");
		} else {
		}
		if (num.matches("^[0-9]{12}$")) {
			Log.e(EXC, "龙邦速递");
			a++;
			c.add("longbanwuliu");
		} else {
		}
		if (num.matches("^[0-9]{11,13}$")) {
			Log.e(EXC, "快捷速递");
			a++;
			c.add("kuaijiesudi");
		} else {
		}
		if (num.matches("^96[0-9]{12}$")) {
			Log.e(EXC, "远长");
			a++;
		} else {
		}
		if (num.matches("[0-9]{8}")) {
			Log.e(EXC, "新邦物流");
			a++;
			c.add("xinbangwuliu");
		} else {
		}
		if (num.matches("^((88|)[0-9]{10})$|^((1|2|3|5|)[0-9]{9})$|^((9|)[0-9]{11})$")) {
			Log.e(EXC, "港中能达");
			a++;
			c.add("ganzhongnengda");
		} else {
		}
		if (num.matches("^VIP[0-9]{9}|V[0-9]{11}|[0-9]{12}$")) {
			Log.e(EXC, "优速物流");
			a++;
			c.add("youshuwuliu");
		} else {
		}
		if (num.matches("^[0-9]{12}$")) {
			Log.e(EXC, "全日通快递");
			a++;
			c.add("quanritongkuaidi");
		} else {
			Log.e(EXC, "其他快递");
		}
		Log.e("快递公司数量", "" + a);
		Log.e("快递参数集合", c.toString());
		return c;
	}
}
