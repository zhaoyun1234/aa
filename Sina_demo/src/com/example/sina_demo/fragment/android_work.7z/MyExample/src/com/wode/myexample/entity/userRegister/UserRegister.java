package com.wode.myexample.entity.userRegister;

import java.io.Serializable;

public class UserRegister implements Serializable{
	private int status;
	private String message;
	public UserRegister(int status, String message) {
		super();
		this.status = status;
		this.message = message;
	}
	public UserRegister() {
		super();
	}
	public int getStatus() {
		return status;
	}
	public void setStatus(int status) {
		this.status = status;
	}
	public String getMessage() {
		return message;
	}
	public void setMessage(String message) {
		this.message = message;
	}
	@Override
	public String toString() {
		return "UserRegister [status=" + status + ", message=" + message + "]";
	}
	

}
