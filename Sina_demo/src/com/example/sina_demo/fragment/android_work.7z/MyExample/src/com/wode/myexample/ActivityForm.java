package com.wode.myexample;

import java.text.ParseException;

import com.wode.myexample.adapter.FromAdapter;
import com.wode.myexample.entity.kuaidi100.KuaiDi100;
import com.wode.myexample.util.ExDays;
import com.wode.myexample.util.ExState;
import com.wode.myexample.util.ExString;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.util.Log;
import android.widget.ListView;
import android.widget.TextView;

public class ActivityForm extends Activity {

	private TextView layout_form_EX_Name, layout_form_EX_Num,
			layout_form_EX_State, layout_form_EX_days;
	private ListView layout_form_ListView;
	private String s1, s2;
	private Handler mHandler;
	private final int DATA_SUCCESS = 1;
	private Context mContext;
	private FromAdapter adapter;
	private KuaiDi100 mDi100;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		setContentView(R.layout.layout_form);
		layout_form_EX_Name = (TextView) findViewById(R.id.layout_form_EX_Name);
		layout_form_EX_Num = (TextView) findViewById(R.id.layout_form_EX_Num);
		layout_form_EX_State = (TextView) findViewById(R.id.layout_form_EX_State);
		layout_form_EX_days = (TextView) findViewById(R.id.layout_form_EX_days);
		layout_form_ListView = (ListView) findViewById(R.id.layout_form_ListView);
		mContext = getApplicationContext();

		mHandler = new Handler() {

			@Override
			public void handleMessage(Message msg) {
				// TODO Auto-generated method stub
				super.handleMessage(msg);
				switch (msg.what) {
				case DATA_SUCCESS:
					Log.e("mHandler", "mHandler");
					KuaiDi100 mKuaiDi100 = (KuaiDi100) msg.obj;
					adapter = new FromAdapter(layout_form_ListView,
							mKuaiDi100.getData(), mContext);
					
					layout_form_ListView.setAdapter(adapter);
					break;
				}
			}
		};

		Intent intent = getIntent();
		mDi100 = (KuaiDi100) intent.getSerializableExtra("kuaidi");
		Log.e("from", mDi100.toString());

		s1 = mDi100.getData().get(mDi100.getData().size() - 1).getTime();
		s2 = mDi100.getData().get(0).getTime();
		Log.e("s1&s2", s1 + "|" + s2);
		try {
			int days = ExDays.days(s1, s2);
			layout_form_EX_days.setText("" + days);
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		new Thread(new Runnable() {

			@Override
			public void run() {
				// TODO Auto-generated method stub

				Message msg = mHandler.obtainMessage(DATA_SUCCESS, mDi100);
				mHandler.sendMessage(msg);
			}
		}).start();

		layout_form_EX_Name.setText(new ExString().ExCodToString(mDi100
				.getCom()));
		layout_form_EX_Num.setText(mDi100.getNu());
		layout_form_EX_State.setText(new ExState().State(mDi100.getState()));

	}

}
