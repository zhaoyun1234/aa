package com.wode.myexample.entity.checkName;

import java.io.Serializable;
/**
 * 验证用户名是否存在
 * @author KiSs_DaDa
 * @data 2014-10-29
 */
public class CheckName implements Serializable{
	private int status;
	private String message;
	private String info;
	public CheckName() {
		super();
	}
	public CheckName(int status, String message, String info) {
		super();
		this.status = status;
		this.message = message;
		this.info = info;
	}
	public int getStatus() {
		return status;
	}
	public void setStatus(int status) {
		this.status = status;
	}
	public String getMessage() {
		return message;
	}
	public void setMessage(String message) {
		this.message = message;
	}
	public String getInfo() {
		return info;
	}
	public void setInfo(String info) {
		this.info = info;
	}
	@Override
	public String toString() {
		return "CheckName [status=" + status + ", message=" + message
				+ ", info=" + info + "]";
	}
	
	
}
